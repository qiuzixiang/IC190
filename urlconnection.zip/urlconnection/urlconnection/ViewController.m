//
//  ViewController.m
//  urlconnection
//
//  Created by user on 2015/12/1.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onGetJson:(id)sender {
    NSMutableURLRequest *req = [[NSMutableURLRequest alloc] init];
    
    req.URL = [NSURL URLWithString:self.txtURL.text];
    
    connect = [[NSURLConnection alloc] initWithRequest:req delegate:self];
    [connect start];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    NSString *backStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSLog(@"backStr = %@", backStr);
    
    self.resultText.text = backStr;
    
    NSString *jsonStr = [backStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    jsonStr = [jsonStr stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    jsonStr = [jsonStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    NSLog(@"jsonStr = %@", jsonStr);
    
    NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err = nil;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&err];
    
    NSLog(@"dict = %@", dict);
}

@end
