//
//  ViewController.h
//  urlconnection
//
//  Created by user on 2015/12/1.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <NSURLConnectionDataDelegate> {
    NSURLConnection *connect;
}

@property (weak, nonatomic) IBOutlet UITextField *txtURL;
@property (weak, nonatomic) IBOutlet UITextView *resultText;

@end

